import java.io.File;
import java.util.Scanner;
public class Ice {

	public static void main(String[] args) throws Exception
	{
		int flag = Integer.valueOf(args[0]);
		
		double data[][] = new double[162][2];
		File file = new File("C:\\Users\\redam\\Desktop\\CS367\\Ice\\src\\data.txt");
		Scanner sc = new Scanner(file);

		for(int i = 0; i < data.length; i++){
			data[i][0] = sc.nextInt(); 
			data[i][1] = sc.nextInt();
		}
		
		
		
		if(flag == 200){
			double dataVar[] = new double[162];
			for(int i = 0; i < data.length; i++){
				dataVar[i] = data[i][1];
			}
			double sum1 = 0.0;
			double sum2 = 0.0;
			double standardDev = 0.0;

			for (int i = 0; i <  dataVar.length; i++) {
				sum1 += dataVar[i];
				sum2 += Math.pow(dataVar[i], 2);
				standardDev = Math.sqrt(i * sum2 - Math.pow(sum1, 2)) / i;
			}
			double mean = sum1 / dataVar.length;
			System.out.println(dataVar.length);
			System.out.format("%.2f%n", mean);
			System.out.format("%.2f%n", standardDev);
		}
		
		if(flag == 300){
			double b0 = Double.valueOf(args[1]);
			double b1 = Double.valueOf(args[2]);
			//Calculate mse
			double regression[] = new double[162];
			double mse = 0.0;
			double mseSummation = 0.0;
			for(int i = 0; i < data.length; i++){
				regression[i] = b0 + (b1 * data[i][0]);
			}
			for(int i = 0; i < regression.length; i++){
				mseSummation += Math.pow(regression[i] - data[i][1], 2);
			}
			mse = mseSummation / regression.length;
			
			System.out.format("%.2f%n", mse);
		}
		
		if(flag == 400){
			double b0 = Double.valueOf(args[1]);
			double b1 = Double.valueOf(args[2]);
			//Calculate mse
			double regression[] = new double[162];
			double mse = 0.0;
			double mseSummation = 0.0;
			for(int i = 0; i < data.length; i++){
				regression[i] = b0 + (b1 * data[i][0]);
			}
			for(int i = 0; i < regression.length; i++){
				mseSummation += Math.pow(regression[i] - data[i][1], 2);
			}
			mse = mseSummation / regression.length;
			
			//Calculate gradient descent
			double gradientb0 = 0.0;
			double gradientb1 = 0.0;
			double gradientb0Summation = 0.0;
			double gradientb1Summation = 0.0;
			for(int i = 0; i < regression.length; i++){
				gradientb0Summation += regression[i] - data[i][1];
			}
			for(int i = 0; i < regression.length; i++){
				gradientb1Summation += (regression[i] - data[i][1]) * data[i][0];
			}
			
			if(flag == 100){
				for(int i = 0; i < data.length; i++){
					System.out.println(data[i][0] + " " + data[i][1]);
				}
			}
			
			gradientb0 = (2 * gradientb0Summation) / regression.length;
			gradientb1 = (2 * gradientb1Summation) / regression.length;
			System.out.format("%.2f%n", gradientb0);
			System.out.format("%.2f%n", gradientb1);
		}
		
		if(flag == 500){
			double b0 = Double.valueOf(args[1]);
			double b1 = Double.valueOf(args[2]);
			//Calculate mse
			double regression[] = new double[162];
			double mse = 0.0;
			double mseSummation = 0.0;
			for(int i = 0; i < data.length; i++){
				regression[i] = b0 + (b1 * data[i][0]);
			}
			for(int i = 0; i < regression.length; i++){
				mseSummation += Math.pow(regression[i] - data[i][1], 2);
			}
			mse = mseSummation / regression.length;
			
			for(int i = 1; i <= b1; i++){
				System.out.print(i + " ");
				System.out.print(descent(regression, data, 0, i));
			}
		}
		
		if(flag == 600){
			double xBar = 0.0;
			double yBar = 0.0;
			double xSum = 0.0;
			double ySum = 0.0;
			double b0Hat = 0.0;
			double b1Hat = 0.0;
			double numerator = 0.0;
			double denominator = 0.0;
			for(int i = 0; i < data.length; i++){
				xSum += data[i][0];
			}
			for(int i = 0; i < data.length; i++){
				ySum += data[i][1];
			}
			xBar = xSum/data.length;
			yBar = ySum/data.length;
			for(int i = 0; i < data.length; i++){
				numerator += (data[i][0] - xBar) * (data[i][1] - yBar);
			}
			for(int i = 0; i < data.length; i++){
				denominator += Math.pow(data[i][0] - xBar, 2);
			}
			b1Hat = numerator/denominator;
			b0Hat = yBar - (b1Hat * xBar);
			
			//Calculate mse
			double regression[] = new double[162];
			double mse = 0.0;
			double mseSummation = 0.0;
			for(int i = 0; i < data.length; i++){
				regression[i] = b0Hat + (b1Hat * data[i][0]);
			}
			for(int i = 0; i < regression.length; i++){
				mseSummation += Math.pow(regression[i] - data[i][1], 2);
			}
			mse = mseSummation / regression.length;
			String b0HatString = String.format("%.2f", b0Hat);
			String b1HatString = String.format("%.2f", b1Hat);
			String mseString = String.format("%.2f", mse);
			
			System.out.println(b0HatString + " " + b1HatString + " " + mseString);
			

		}
		
		if(flag == 700){
			double year = Double.valueOf(args[1]);
			double xBar = 0.0;
			double yBar = 0.0;
			double xSum = 0.0;
			double ySum = 0.0;
			double b0Hat = 0.0;
			double b1Hat = 0.0;
			double numerator = 0.0;
			double denominator = 0.0;
			for(int i = 0; i < data.length; i++){
				xSum += data[i][0];
			}
			for(int i = 0; i < data.length; i++){
				ySum += data[i][1];
			}
			xBar = xSum/data.length;
			yBar = ySum/data.length;
			for(int i = 0; i < data.length; i++){
				numerator += (data[i][0] - xBar) * (data[i][1] - yBar);
			}
			for(int i = 0; i < data.length; i++){
				denominator += Math.pow(data[i][0] - xBar, 2);
			}
			b1Hat = numerator/denominator;
			b0Hat = yBar - (b1Hat * xBar);
			double result = b0Hat + (b1Hat * year);
			System.out.format("%.2f", result);

		}
		
		if(flag == 800){
			double b0 = Double.valueOf(args[1]);
			double b1 = Double.valueOf(args[2]);
			double xBar = 0.0;
			double std = 0.0;
			double sum1 = 0.0;
			double xSum = 0.0;
			double notMean = 0.0;
			double newData[] = new double [162];
			for(int i = 0; i < data.length; i++){
				xSum += data[i][0];
			}
			xBar = xSum/data.length;
			for(int i = 0; i < data.length; i++){
				sum1 += Math.pow(data[i][0] - xBar, 2);
			}
			notMean = (1/(data.length - 1) * sum1);
			std = Math.pow(notMean, 0.5);
			for(int i = 0; i < newData.length; i++){
				newData[i] = ((data[i][0] - xBar) - std);
			}
			for(int i = 1; i <= b1; i++){
				System.out.print(i + " ");
				System.out.print(descent(newData, data, 0, i));
			}
			
		}
		
		if(flag == 900){

		}
	}
	public static String descent(double regressionData[], double data2[][], double b0, double b1){
		double gradientb0 = 0.0;
		double gradientb1 = 0.0;
		double n = b0;
		double b1t = b1;
		double gradientb0Summation = 0.0;
		double gradientb1Summation = 0.0;
		double gradientDescentb0Summation = 0.0;
		double gradientDescentb1Summation = 0.0;
		double descentb0 = 0.0;
		double descentb1 = 0.0;
		double gradient[] = new double[162];
		double mse = 0.0;
		double mseSummation = 0.0;
		for(int i = 0; i < regressionData.length; i++){
			gradientb0Summation += n + (b1t * data2[i][0]) - data2[i][1] ;
		}
		for(int i = 0; i < regressionData.length; i++){
			gradientb1Summation += (n + (b1t * data2[i][0]) - data2[i][1]) * data2[i][0];
		}
		
		gradientb0 = (2 * gradientb0Summation) / regressionData.length;
		gradientb1 = (2 * gradientb1Summation) / regressionData.length;
		
		//new b0 and b1
		descentb0 = (b0) - (n * gradientb0);
		descentb1 = (b1) - (n * gradientb0);
		
		//new data set
		for(int i = 0; i < data2.length; i++){
			gradient[i] = descentb0 + (descentb1 * data2[i][0]);
		}
		
		//new mse
		for(int i = 0; i < gradient.length; i++){
			mseSummation += Math.pow(gradient[i] - data2[i][1], 2);
		}
		mse = mseSummation / gradient.length;
		double result[] = new double[3];
		result[0] = descentb0;
		result[1] = descentb1;
		result[2] = mse;
		String result0 = String.format("%.2f", result[0]);
		String result1 = String.format("%.2f", result[1]);
		String result2 = String.format("%.2f%n", result[2]);
		
		
		return result0 + " " + result1 + " " + result2;
	}
}
